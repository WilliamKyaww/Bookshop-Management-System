
public enum Condition {
    NEW, 
    USED;
}