
public enum Genre {
    POLITICS,
    BUSINESS,
    COMPUTER_SCIENCE,
    BIOGRAPHY
}
