
public enum EbookFormat {
    EPUB,
    MOBI,
    PDF
}
