
public enum Language {
    ENGLISH,
    FRENCH
}

