
public enum BookType {
    PAPERBACK,
    EBOOK,
    AUDIOBOOK
}

